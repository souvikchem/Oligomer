# Oligomer_program
Oligomer_file
The codes and corresponding input files are in the .zip file in code. 
One can run the program by 
f95xtc Program.F90
following by 
./a.out <file.inp
If one has trajectory file then he/she can easily complie the program.
